(function(){
  function initScene() {
    const canvas = document.getElementById('scene');
    if(!canvas) {
      console.warn('Canvas not found, retrying...');
      return setTimeout(initScene, 50);
    }
    const ctx = canvas.getContext('2d');

  // resize to full screen
  function fit(){ canvas.width = window.innerWidth; canvas.height = window.innerHeight; }
  window.addEventListener('resize', fit, {passive:true});
  fit();

  // 3D Particle System State
  let t=0, energy=0.25, mood=0; // mood -1..1
  const baseForm = 'swarm';
  let targetShape = baseForm; // 'swarm' | 'cube' | 'sphere' | 'wave' | 'helix' | 'torus'
  let visualMode = 'Quick Hit'; // affects style
  const style = { 
    jitter: 1.0, 
    rotationSpeed: 0.002, 
    colorA: '#00e6ff', 
    colorB: '#38f0c8', 
    brightness: 1.2,
    particleSize: 2.5,
    glowRadius: 8
  };
  let thinking = { active:false };
  
  // 3D Camera and perspective
  const camera = {
    x: 0, y: 0, z: -500,
    rotX: 0, rotY: 0, rotZ: 0,
    fov: 800
  };
  
  // performance governor: auto-tune density & effects to protect CPU/GPU (Chromebook-friendly)
  const perf = {
    mode: 'auto', // 'auto' | 'low' | 'high'
    avgMs: 16,
    lastNow: performance.now(),
    adjustEvery: 30,
    frames: 0,
    stride: 1,
    glowScale: 1.0,
    reduceMotion: (typeof window.matchMedia === 'function') && window.matchMedia('(prefers-reduced-motion: reduce)').matches,
    hidden: document.hidden,
    targetFPS: 60,
    qualityLevel: 'high'
  };
  
  // 3D Particle system - enhanced for shape formation
  let points = new Array(1800).fill(0).map((_, i)=>({
    // 3D position
    x: (Math.random() - 0.5) * 400,
    y: (Math.random() - 0.5) * 400, 
    z: (Math.random() - 0.5) * 400,
    // Previous position for motion
    px: 0, py: 0, pz: 0,
    // Target position for shape formation
    tx: 0, ty: 0, tz: 0,
    // Rendered 2D position
    sx: 0, sy: 0,
    // Properties
    id: i,
    phase: Math.random() * Math.PI * 2,
    speed: 0.02 + Math.random() * 0.03,
    life: 1.0,
    size: 1.0 + Math.random() * 2.0
  }));
  
  // Enhanced startup with quality detection
  setTimeout(()=>{
    const canvas = document.getElementById('scene');
    const isHighEnd = canvas && canvas.width > 1920 && navigator.hardwareConcurrency > 4;
    const isMobile = /Android|iPhone|iPad/.test(navigator.userAgent);
    
    if (isMobile) {
      perf.qualityLevel = 'medium';
      perf.stride = 2;
      points = points.slice(0, 900); // Reduce particle count
    } else if (isHighEnd) {
      perf.qualityLevel = 'high';
      points = new Array(2400).fill(0).map((_, i)=>({
        x: (Math.random() - 0.5) * 400,
        y: (Math.random() - 0.5) * 400, 
        z: (Math.random() - 0.5) * 400,
        px: 0, py: 0, pz: 0,
        tx: 0, ty: 0, tz: 0,
        sx: 0, sy: 0,
        id: i,
        phase: Math.random() * Math.PI * 2,
        speed: 0.02 + Math.random() * 0.03,
        life: 1.0,
        size: 1.0 + Math.random() * 2.0
      }));
    }
  }, 100);
    
    perf.stride = 1;
    perf.glowScale = 1.0;
    energy = 0.8; // boost initial energy for visibility
    console.log('Clever optimized:', points.length, 'particles,', perf.qualityLevel, 'quality, stride', perf.stride);
  // 3D Math Functions
  function project3D(x, y, z) {
    // Rotate around Y axis (left-right rotation)
    const cosY = Math.cos(camera.rotY);
    const sinY = Math.sin(camera.rotY);
    const rotX = cosY * x - sinY * z;
    const rotZ = sinY * x + cosY * z;
    
    // Rotate around X axis (up-down rotation)
    const cosX = Math.cos(camera.rotX);
    const sinX = Math.sin(camera.rotX);
    const finalY = cosX * y - sinX * rotZ;
    const finalZ = sinX * y + cosX * rotZ + camera.z;
    
    // Perspective projection
    if (finalZ > -50) return null; // Behind camera
    
    const scale = camera.fov / -finalZ;
    return {
      x: canvas.width/2 + rotX * scale,
      y: canvas.height/2 + finalY * scale,
      z: finalZ,
      scale: scale
    };
  }
  
  // 3D Shape Generators
  function generateSphere(radius = 150, particles = points) {
    particles.forEach((p, i) => {
      const phi = Math.acos(1 - 2 * (i + 0.5) / particles.length);
      const theta = Math.PI * (1 + Math.sqrt(5)) * i;
      
      p.tx = radius * Math.sin(phi) * Math.cos(theta);
      p.ty = radius * Math.sin(phi) * Math.sin(theta);
      p.tz = radius * Math.cos(phi);
    });
  }
  
  function generateCube(size = 120, particles = points) {
    const half = size / 2;
    particles.forEach((p, i) => {
      const face = i % 6;
      const u = (Math.random() - 0.5) * size;
      const v = (Math.random() - 0.5) * size;
      
      switch(face) {
        case 0: p.tx = half; p.ty = u; p.tz = v; break;    // Right
        case 1: p.tx = -half; p.ty = u; p.tz = v; break;   // Left
        case 2: p.tx = u; p.ty = half; p.tz = v; break;    // Top
        case 3: p.tx = u; p.ty = -half; p.tz = v; break;   // Bottom
        case 4: p.tx = u; p.ty = v; p.tz = half; break;    // Front
        case 5: p.tx = u; p.ty = v; p.tz = -half; break;   // Back
      }
    });
  }
  
  function generateHelix(radius = 80, height = 200, turns = 3, particles = points) {
    particles.forEach((p, i) => {
      const t = (i / particles.length) * turns * Math.PI * 2;
      const y = (i / particles.length - 0.5) * height;
      
      p.tx = radius * Math.cos(t);
      p.ty = y;
      p.tz = radius * Math.sin(t);
    });
  }
  
  function generateTorus(majorRadius = 100, minorRadius = 30, particles = points) {
    particles.forEach((p, i) => {
      const u = (i / particles.length) * Math.PI * 2;
      const v = ((i * 7) % particles.length / particles.length) * Math.PI * 2;
      
      p.tx = (majorRadius + minorRadius * Math.cos(v)) * Math.cos(u);
      p.ty = minorRadius * Math.sin(v);
      p.tz = (majorRadius + minorRadius * Math.cos(v)) * Math.sin(u);
    });
  }
  
  function generateSwarm(particles = points) {
    const centerX = 0, centerY = 0, centerZ = 0;
    const swarmRadius = 200;
    
    particles.forEach((p, i) => {
      // Organic swarm movement
      const angle1 = (i / particles.length) * Math.PI * 2 + t * 0.001;
      const angle2 = (i * 3.7 / particles.length) * Math.PI * 2 + t * 0.0007;
      const r = swarmRadius * (0.3 + 0.7 * Math.sin(i * 0.01 + t * 0.002));
      
      p.tx = centerX + r * Math.cos(angle1) * Math.sin(angle2);
      p.ty = centerY + r * Math.sin(angle1) * 0.6;
      p.tz = centerZ + r * Math.cos(angle1) * Math.cos(angle2);
    });
  }
  
  function generateWave(amplitude = 80, frequency = 0.02, particles = points) {
    const width = 300;
    const depth = 300;
    
    particles.forEach((p, i) => {
      const x = (i % 30 - 15) * (width / 30);
      const z = Math.floor(i / 30) * (depth / Math.ceil(particles.length / 30)) - depth/2;
      const wave1 = Math.sin(x * frequency + t * 0.003) * amplitude;
      const wave2 = Math.cos(z * frequency + t * 0.002) * amplitude * 0.5;
      
      p.tx = x;
      p.ty = wave1 + wave2;
      p.tz = z;
    });
  }
  let swirl = {active:false, start:0, duration:500};
  let dissolve = {active:false, start:0, duration:600};
  let morphBusy = false;
  // text morph (pixel-born panels)
  const textMorph = { active:false, start:0, duration:1600, targets:null, map:null };
  const textCanvas = document.createElement('canvas');
  const textCtx = textCanvas.getContext('2d');
  // ambient ember layer (lightweight, always-on)
  const EMBER_BASE = 160;
  let emberLevel = 1.0; // 0.5 .. 2.5
  let emberBrightness = 1.0; // 0.6 .. 1.8
  let embers = new Array(Math.floor(EMBER_BASE*emberLevel)).fill(0).map(()=>({x:0,y:0,vx:0,vy:0,a:Math.random()*Math.PI*2,r:0,tw:Math.random()*6.28}));
  
  // Add missing variables
  let ringPhase = 0;
  const rot3d = { ax: 0, ay: 0 };
  
  function setParticleLevel(level){
    emberLevel = Math.max(0.4, Math.min(2.8, level||1));
    const need = Math.floor(EMBER_BASE*emberLevel);
    if (need > embers.length){
      const add = new Array(need - embers.length).fill(0).map(()=>({x:0,y:0,vx:0,vy:0,a:Math.random()*Math.PI*2,r:0,tw:Math.random()*6.28}));
      embers = embers.concat(add);
    } else if (need < embers.length){
      embers.length = need;
    }
  }
  function setParticleBrightness(f){ emberBrightness = Math.max(0.5, Math.min(1.8, f||1)); }
  window.__sceneSetParticleLevel = setParticleLevel;
  window.__sceneSetParticleBrightness = setParticleBrightness;
  // manual perf controls for the UI/console: __scenePerf('low'|'auto'|'high')
  window.__scenePerf = function(mode){
    if (!mode) return perf.mode;
    const m = (''+mode).toLowerCase();
    if (m === 'low'){
      perf.mode = 'low'; perf.stride = 3; perf.glowScale = 0.6; setParticleLevel(0.8); setParticleBrightness(0.8);
    } else if (m === 'high'){
      perf.mode = 'high'; perf.stride = 1; perf.glowScale = 1.0; setParticleLevel(1.2); setParticleBrightness(1.0);
    } else {
      perf.mode = 'auto';
    }
  };
  // respect reduced-motion preference by defaulting to low when requested
  if (perf.reduceMotion) { window.__scenePerf('low'); }
  document.addEventListener('visibilitychange', ()=>{ perf.hidden = document.hidden; });
  window.__sceneParticles = function(cmd){
    if (cmd === 'up' || cmd === 'more') setParticleLevel(emberLevel + 0.3);
    else if (cmd === 'down' || cmd === 'less') setParticleLevel(emberLevel - 0.3);
    else if (typeof cmd === 'number') setParticleLevel(cmd);
    pulse(0.2);
  };

  function setShape(name){ targetShape = name || baseForm; }
  function pulse(a){ energy = Math.min(1, energy + (a||0.25)); }
  function setMood(m){ mood = Math.max(-1, Math.min(1, m||0)); }
  window.__orbSetMood = setMood; // keep same names for compatibility
  window.__orbPulse = pulse;
  window.__orbBrighten = function(){ pulse(0.5); };
  window.__orbSetMode = function(m){
    if (!m) return;
    visualMode = m;
    if (m === 'Deep Dive'){ style.jitter = 0.9; style.ringSpeed = 0.0022; style.brightness = 0.95; }
    else if (m === 'Creative'){ style.jitter = 1.25; style.ringSpeed = 0.0035; style.brightness = 1.1; }
    else if (m === 'Support'){ style.jitter = 0.85; style.ringSpeed = 0.0026; style.brightness = 1.0; }
    else { style.jitter = 1.0; style.ringSpeed = 0.003; style.brightness = 1.0; }
  };
  window.__orbThinking = function(on){ thinking.active = !!on; if (on) pulse(0.1); };
  window.__sceneSetShape = setShape;
  window.__sceneMorphForDialogue = function(meta){
    const m = meta || {};
    const shape = (m.shape || m.shape_to_form || '').toLowerCase();
    const hold = Math.max(600, Math.min(4000, m.holdMs != null ? m.holdMs : 1600));
    morphTo(shape || 'cube', hold);
  };

  // Public: lightweight pixel-born panel for short text
  window.__sceneSpeakText = function(text, opts){
    const s = (text||'').trim();
    if (!s) return;
    // Avoid heavy effect on low mode
    if (perf.mode === 'low' || perf.stride > 2) return;
    const maxChars = (canvas.width<700? 26: 36);
    const msg = s.length > maxChars ? s.slice(0, maxChars-1) + '…' : s;
    // build targets
    const padding = 24;
    textCanvas.width = Math.min(canvas.width - padding*2, 900);
    textCanvas.height = Math.min(180, Math.max(90, Math.floor(canvas.height*0.18)));
    textCtx.clearRect(0,0,textCanvas.width, textCanvas.height);
    // font size responsive
    const fs = Math.min(64, Math.max(24, Math.floor(textCanvas.width / (msg.length*0.6))));
    textCtx.font = `bold ${fs}px system-ui, Segoe UI, Roboto, Arial`;
    textCtx.textAlign = 'center'; textCtx.textBaseline = 'middle';
    textCtx.fillStyle = '#ffffff';
    textCtx.fillText(msg, textCanvas.width/2, textCanvas.height/2);
    // sample points
    const step = 6; const pts = [];
    const img = textCtx.getImageData(0,0,textCanvas.width, textCanvas.height).data;
    for (let y=0;y<textCanvas.height;y+=step){
      for (let x=0;x<textCanvas.width;x+=step){
        const idx = (y*textCanvas.width + x)*4 + 3; // alpha
        if (img[idx] > 96) {
          pts.push({x, y});
        }
      }
    }
    // map to screen coords near the orb
    const cx = canvas.width/2, cy = canvas.height*0.68;
    const left = cx - textCanvas.width/2, top = cy - textCanvas.height/2;
    const targets = pts.map(p => ({x: left + p.x, y: top + p.y}));
    // choose subset of particles
    const useCount = Math.min(targets.length, Math.floor(points.length / Math.max(2, perf.stride*2)));
    const chosenIdx = new Set();
    while (chosenIdx.size < useCount){
      chosenIdx.add(Math.floor(Math.random()*points.length));
    }
    const map = new Array(points.length).fill(null);
    let tix = 0;
    chosenIdx.forEach(i => { map[i] = targets[tix++ % targets.length]; });
    textMorph.active = true; textMorph.start = performance.now(); textMorph.targets = targets; textMorph.map = map;
    // auto stop
    setTimeout(()=>{ textMorph.active=false; textMorph.map=null; }, Math.max(800, Math.min(2600, (opts&&opts.holdMs)||textMorph.duration)));
  };

  function morphTo(shape, holdMs){
    if (morphBusy) return; // throttle overlapping morphs
    morphBusy = true;
    // swirl up a bit for flourish
    swirl.active = true; swirl.start = performance.now();
    setTimeout(()=>{ swirl.active = false; setShape(shape); pulse(0.3); }, 120);
    // return to base after hold
    setTimeout(()=>{
      // dissolve back to swarm
      dissolve.active = true; dissolve.start = performance.now();
      setTimeout(()=>{ setShape(baseForm); dissolve.active = false; morphBusy = false; }, Math.min(800, Math.max(300, Math.floor(dissolve.duration*0.9))));
    }, holdMs);
  }

  // target fields
  function targetRing(i, count, cx, cy, base){
    // alive: slow rotation and gentle breathing
    const live = 0.0025;
    const a = (i/count)*Math.PI*2 + ringPhase + (swirl.active ? (Math.sin((performance.now()-swirl.start)/120) * 0.3) : 0);
    const r = base + Math.sin(i*0.02 + t*0.02)*8*energy + Math.sin(t*0.02)*6;
    return {x: cx + Math.cos(a)*r, y: cy + Math.sin(a)*r};
  }
  // 3D helpers
  function rotateProject(x,y,z){
    // rotate around Y then X
    const sy = Math.sin(rot3d.ay), cy = Math.cos(rot3d.ay);
    const sx = Math.sin(rot3d.ax), cx = Math.cos(rot3d.ax);
    let xr =  cy*x + sy*z;
    let zr = -sy*x + cy*z;
    let yr =  cx*y - sx*zr;
    zr =  sx*y + cx*zr;
    // lightweight perspective
    const d = 600; // camera distance
    const f = d / (d - zr);
    return { x: xr * f, y: yr * f };
  }
  function targetSphere(i, count, cx, cy, base){
    // Fibonacci sphere for even distribution
    const n = Math.max(1, count);
    const ga = Math.PI * (3 - Math.sqrt(5));
    const y = 1 - (2*i)/(n-1);
    const r = Math.sqrt(Math.max(0,1 - y*y));
    const a = ga * i;
    const x = Math.cos(a)*r;
    const z = Math.sin(a)*r;
    const p = rotateProject(x*base, y*base, z*base);
    return { x: cx + p.x, y: cy + p.y };
  }
  function targetTorus(i, count, cx, cy, base){
    // parametric torus
    const n = Math.max(1, count);
    const u = (i / n) * Math.PI * 2;
    const k = 0.61803398875; // spread v quasi-randomly
    const v = ((i * k) % 1) * Math.PI * 2;
    const R = base*0.8; // major
    const r = base*0.28; // minor
    const x = (R + r*Math.cos(v)) * Math.cos(u);
    const y = r * Math.sin(v);
    const z = (R + r*Math.cos(v)) * Math.sin(u);
    const p = rotateProject(x, y, z);
    return { x: cx + p.x, y: cy + p.y };
  }
  function targetKnot(i, count, cx, cy, base){
    // Trefoil knot curve (tube implied by jitter)
    const t = (i / Math.max(1,count)) * Math.PI * 2;
    const x = (2 + Math.cos(3*t)) * Math.cos(2*t) * (base*0.3);
    const y = Math.sin(3*t) * (base*0.3);
    const z = (2 + Math.cos(3*t)) * Math.sin(2*t) * (base*0.3);
    const p = rotateProject(x, y, z);
    return { x: cx + p.x, y: cy + p.y };
  }
  function targetPyramid(i, count, cx, cy, base){
    // square base pyramid perimeter
    const per = Math.max(4, Math.floor(count/4));
    const side = (i % (per*4));
    const half = base*0.65;
    let x=0,y=0,z=0;
    // base at y = -h/4, apex at +h
    const h = base*0.8;
    if (side < per){ // top edge (z = -half)
      const u = side/per; x = -half + u*2*half; z = -half; y = -h*0.25;
    } else if (side < per*2) {
      const u = (side-per)/per; x = half; z = -half + u*2*half; y = -h*0.25;
    } else if (side < per*3) {
      const u = (side-per*2)/per; x = half - u*2*half; z = half; y = -h*0.25;
    } else {
      const u = (side-per*3)/per; x = -half; z = half - u*2*half; y = -h*0.25;
    }
    // interpolate some points to apex for variety
    if ((i % 7) === 0){ x *= 0.5; z *= 0.5; y = h*0.55; }
    const p = rotateProject(x, y, z);
    return { x: cx + p.x, y: cy + p.y };
  }
  function targetCube(i, count, cx, cy, base){
    // distribute around a square perimeter
    const per = Math.max(4, Math.floor(count/4));
    const side = (i % (per*4));
    const half = base;
    let x=0,y=0;
    if (side < per) { // top edge
      const u = side/per; x = -half + u*2*half; y = -half;
    } else if (side < per*2) {
      const u = (side-per)/per; x = half; y = -half + u*2*half;
    } else if (side < per*3) {
      const u = (side-per*2)/per; x = half - u*2*half; y = half;
    } else {
      const u = (side-per*3)/per; x = -half; y = half - u*2*half;
    }
    // wobble for life
    x += Math.sin(i*0.03 + t*0.03)*6*energy;
    y += Math.cos(i*0.02 - t*0.025)*6*energy;
    return {x: cx + x, y: cy + y};
  }
  function targetWave(i, count, cx, cy, base){
    const cols = Math.floor(Math.sqrt(count));
    const rows = Math.floor(count/cols);
    const col = i % cols; const row = Math.floor(i/cols);
    const spacing = Math.min(18, (base*2)/cols);
    const x = cx - (cols*spacing)/2 + col*spacing;
    const y = cy + (row - rows/2)*spacing + Math.sin((col*0.3 + t*0.05))*8*energy;
    return {x,y};
  }

  function target(i){
    const cx = canvas.width/2, cy = canvas.height*0.7; // lower for a ground feel
    // text targets override for selected particles
    if (textMorph.active && textMorph.map && textMorph.map[i]){
      const m = textMorph.map[i];
      return {x: m.x, y: m.y};
    }
  const base = Math.min(canvas.width, canvas.height)*0.22;
  if (targetShape === 'cube') return targetCube(i, points.length, cx, cy, base);
  if (targetShape === 'wave') return targetWave(i, points.length, cx, cy, base*0.9);
  if (targetShape === 'sphere') return targetSphere(i, points.length, cx, cy, base*1.05);
  if (targetShape === 'torus') return targetTorus(i, points.length, cx, cy, base*1.0);
  if (targetShape === 'knot') return targetKnot(i, points.length, cx, cy, base*1.0);
  if (targetShape === 'pyramid') return targetPyramid(i, points.length, cx, cy, base*1.0);
    return targetRing(i, points.length, cx, cy, base);
  }

  function bg(){
    // gentle trail fade for alive motion; slightly lighter fade if on low perf
    const alpha = (perf.mode === 'low' || perf.stride > 1) ? 0.14 : 0.18;
    ctx.fillStyle = 'rgba(0,0,0,'+alpha+')';
    ctx.fillRect(0,0,canvas.width, canvas.height);
  }

  function neon(color, glow){
    ctx.fillStyle = color;
    ctx.shadowBlur = glow; ctx.shadowColor = color;
  }

  function moodColors(){
    // map mood [-1..1] to a pair
    if (mood > 0.2) return ['#33ffd6', '#ffe08a']; // friendly/positive
    if (mood < -0.2) return ['#77a8ff', '#b583ff']; // focused/cool
    return ['#00e6ff', '#38f0c8']; // neutral/inquisitive
  }

  function moodTint(){
    if (Math.abs(mood) < 0.05) return 'rgba(0,0,0,0)';
    return mood > 0 ? 'rgba(255,200,120,0.08)' : 'rgba(120,180,255,0.08)';
  }

  function step(){
    // frame timing
    const now = performance.now();
    const dt = Math.max(0.0001, now - perf.lastNow);
    perf.lastNow = now;
    // EWMA for average frame time
    perf.avgMs = perf.avgMs * 0.9 + dt * 0.1;
    perf.frames++;

    t++;
    bg();
    const n = points.length;
    const mc = moodColors();
    const col1 = mc[0], col2 = mc[1];
    // keep her alive: slow rotation baseline
    ringPhase += style.rotationSpeed;

    // Enhanced auto-governor: smarter adaptation with quality levels
    if (perf.frames % perf.adjustEvery === 0 && perf.mode === 'auto' && !perf.hidden){
      const targetMs = 1000 / perf.targetFPS; // 16.67ms for 60fps
      
      if (perf.avgMs > targetMs + 5){
        // Performance is struggling - reduce quality more aggressively
        if (perf.qualityLevel === 'high') {
          perf.qualityLevel = 'medium';
          perf.stride = Math.min(3, perf.stride + 1);
          setParticleLevel(emberLevel - 0.2);
        } else if (perf.qualityLevel === 'medium') {
          perf.qualityLevel = 'low';
          perf.stride = Math.min(4, perf.stride + 1);
          setParticleLevel(Math.max(0.5, emberLevel - 0.3));
        }
        perf.glowScale = Math.max(0.4, perf.glowScale * 0.85);
        console.log('Clever quality reduced to', perf.qualityLevel, 'due to performance');
      } else if (perf.avgMs < targetMs - 3){
        // Performance is good - can increase quality
        if (perf.qualityLevel === 'low') {
          perf.qualityLevel = 'medium';
          perf.stride = Math.max(1, perf.stride - 1);
          setParticleLevel(Math.min(1.2, emberLevel + 0.2));
        } else if (perf.qualityLevel === 'medium' && perf.avgMs < targetMs - 6) {
          perf.qualityLevel = 'high';
          setParticleLevel(Math.min(1.5, emberLevel + 0.3));
        }
        perf.glowScale = Math.min(1.2, perf.glowScale * 1.05);
      }
    }

    // evolve 3D rotation slightly for alive feel (very small to keep calm)
    rot3d.ay += 0.0025; rot3d.ax += 0.0015;

    // draw embers first (behind main swarm)
    {
      const cx = canvas.width/2, cy = canvas.height*0.7;
      const base = Math.min(canvas.width, canvas.height)*0.28;
      for(let i=0;i<embers.length;i++){
        const e = embers[i];
        if (!e.r) {
          // seed in an annulus around the ring
          e.r = base*0.6 + Math.random()*base*0.7;
          e.a = Math.random()*Math.PI*2;
          e.x = cx + Math.cos(e.a)*e.r;
          e.y = cy + Math.sin(e.a)*e.r;
          e.vx = (Math.random()-0.5)*0.15;
          e.vy = (Math.random()-0.5)*0.15;
          e.tw = Math.random()*6.28;
        }
        // slow orbit + slight turbulence by energy
        e.a += 0.0008 + 0.0015*energy;
        e.r += Math.sin((i*0.37 + t*0.003))*0.12;
        const tx = cx + Math.cos(e.a)*e.r;
        const ty = cy + Math.sin(e.a)*e.r;
        e.vx += (tx - e.x)*0.005; e.vy += (ty - e.y)*0.005;
        e.vx *= 0.985; e.vy *= 0.985;
        e.x += e.vx; e.y += e.vy;
        // render tiny glowing mote
        const twinkle = 0.5 + 0.5*Math.abs(Math.sin(e.tw + t*0.03 + i*0.017));
        const alphaBase = (0.08 + 0.09*Math.max(0,Math.abs(mood))) * emberBrightness;
        const hueWarm = 'rgba(255,220,160,' + Math.min(0.28, alphaBase* (mood>0? 1.1:0.9) * twinkle) + ')';
        const hueCool = 'rgba(80,180,255,' + Math.min(0.28, alphaBase* (mood<0? 1.1:0.9) * twinkle) + ')';
        const useWarm = mood > 0 && (i%3===0);
        ctx.beginPath();
        ctx.arc(e.x, e.y, (0.9 + energy*0.8) * (0.9 + 0.3*emberBrightness), 0, Math.PI*2);
        ctx.shadowBlur = (12 + energy*12) * perf.glowScale;
        ctx.shadowColor = useWarm ? '#ffc890' : '#7fd0ff';
        ctx.fillStyle = useWarm ? hueWarm : hueCool;
        ctx.fill();
      }
    }

    // Main 3D particle rendering
    if (perf.hidden) return requestAnimationFrame(step);
    
    // Camera rotation for dynamic viewing
    camera.rotY += style.rotationSpeed;
    camera.rotX = Math.sin(t * 0.001) * 0.1;
    
    // Generate target positions based on current shape
    if (targetShape === 'sphere') {
      generateSphere(120 + Math.sin(t * 0.002) * 20);
    } else if (targetShape === 'cube') {
      generateCube(100 + Math.sin(t * 0.003) * 15);
    } else if (targetShape === 'helix') {
      generateHelix(60, 180, 2.5);
    } else if (targetShape === 'torus') {
      generateTorus(80, 25);
    } else if (targetShape === 'wave') {
      generateWave(60, 0.025);
    } else {
      generateSwarm(); // default organic swarm
    }

    // Color based on energy and mood
    const energyBlend = Math.min(1, energy * 1.5);
    const col1Interp = interpolateColor(style.colorA, style.colorB, energyBlend);
    const col2Interp = interpolateColor(style.colorB, style.colorA, energyBlend);

    // Update and render particles in 3D
    const visibleParticles = [];
    
    for (let i = 0; i < points.length; i += perf.stride) {
      const p = points[i];
      
      // Move towards target position
      const lerpFactor = 0.03 + energy * 0.02;
      p.x += (p.tx - p.x) * lerpFactor;
      p.y += (p.ty - p.y) * lerpFactor;
      p.z += (p.tz - p.z) * lerpFactor;
      
      // Add organic motion
      const jitterAmount = 2.0 * energy * style.jitter;
      p.x += Math.sin(p.phase + t * 0.003) * jitterAmount;
      p.y += Math.cos(p.phase * 1.3 + t * 0.002) * jitterAmount;
      p.z += Math.sin(p.phase * 0.7 + t * 0.004) * jitterAmount * 0.5;
      
      // Update phase for continuous motion
      p.phase += p.speed;
      
      // Project to 2D screen coordinates
      const projected = project3D(p.x, p.y, p.z);
      if (projected) {
        p.sx = projected.x;
        p.sy = projected.y;
        p.depth = -projected.z;
        p.scale = projected.scale;
        visibleParticles.push({ particle: p, index: i, depth: p.depth });
      }
    }
    
    // Sort by depth for proper rendering
    visibleParticles.sort((a, b) => b.depth - a.depth);
    
    // Render particles with depth-based effects
    for (const { particle: p, index: i } of visibleParticles) {
      const depthFactor = Math.max(0.1, Math.min(1.0, p.scale * 0.002));
      const size = (style.particleSize + Math.sin(i + t * 0.04) * 0.8) * p.size * depthFactor;
      const alpha = depthFactor * style.brightness;
      
      if (size > 0.3 && alpha > 0.05) {
        // Glow effect
        ctx.beginPath();
        ctx.arc(p.sx, p.sy, size * 1.8, 0, Math.PI * 2);
        const rgbCol = hexToRgb(i % 2 ? col1Interp : col2Interp);
        ctx.fillStyle = `rgba(${rgbCol.r}, ${rgbCol.g}, ${rgbCol.b}, ${alpha * 0.4})`;
        ctx.shadowBlur = style.glowRadius * depthFactor * perf.glowScale;
        ctx.shadowColor = i % 2 ? col1Interp : col2Interp;
        ctx.fill();
        
        // Core particle
        ctx.shadowBlur = 0;
        ctx.beginPath();
        ctx.arc(p.sx, p.sy, size * 0.6, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(255, 255, 255, ${alpha})`;
        ctx.fill();
      }
    }

    // Mood overlay
    if (mood !== 0) {
      const moodAlpha = Math.abs(mood) * 0.1;
      const moodColor = mood > 0 ? 'rgba(0, 230, 255, ' : 'rgba(255, 100, 100, ';
      ctx.fillStyle = moodColor + moodAlpha + ')';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    }

    // Thinking indicator
    if (thinking.active) {
      const cx = canvas.width / 2;
      const cy = canvas.height * 0.7;
      const radius = 80 + Math.sin(t * 0.006) * 10;
      
      ctx.beginPath();
      ctx.arc(cx, cy, radius, 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
      ctx.lineWidth = 2;
      ctx.shadowBlur = 20;
      ctx.shadowColor = '#00e6ff';
      ctx.stroke();
      ctx.shadowBlur = 0;
    }

    // Energy decay
    energy = Math.max(0.15, energy * 0.985);
    
    requestAnimationFrame(step);
  }
  
  // Helper functions
  function interpolateColor(color1, color2, factor) {
    const c1 = hexToRgb(color1);
    const c2 = hexToRgb(color2);
    const r = Math.round(c1.r + (c2.r - c1.r) * factor);
    const g = Math.round(c1.g + (c2.g - c1.g) * factor);
    const b = Math.round(c1.b + (c2.b - c1.b) * factor);
    return `rgb(${r}, ${g}, ${b})`;
  }
  
  function hexToRgb(hex) {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
      r: parseInt(result[1], 16),
      g: parseInt(result[2], 16),
      b: parseInt(result[3], 16)
    } : { r: 0, g: 230, b: 255 };
  }

  // Shape morphing system
  function morphTo(shapeName, holdMs = 2000) {
    if (morphBusy) return;
    morphBusy = true;
    
    setShape(shapeName);
    pulse(0.4); // Energy boost for the morph
    
    setTimeout(() => {
      morphBusy = false;
      setShape('swarm'); // Return to organic swarm
    }, holdMs);
  }
  
  // Initialize particles with random 3D positions
  function initializeParticles() {
    const cx0 = 0, cy0 = 0, cz0 = 0;
    points.forEach(p => {
      p.x = cx0 + (Math.random() - 0.5) * 300;
      p.y = cy0 + (Math.random() - 0.5) * 300;
      p.z = cz0 + (Math.random() - 0.5) * 300;
      p.px = p.x; p.py = p.y; p.pz = p.z;
      p.tx = p.x; p.ty = p.y; p.tz = p.z;
    });
  }
  
  // Update global functions for 3D shapes
  window.__sceneSetShape = function(name) {
    const validShapes = ['swarm', 'sphere', 'cube', 'helix', 'torus', 'wave'];
    if (validShapes.includes(name)) {
      setShape(name);
      pulse(0.3);
    }
  };
  
  // Enhanced dialogue morphing
  window.__sceneMorphForDialogue = function(meta) {
    const m = meta || {};
    const shape = (m.shape || m.shape_to_form || '').toLowerCase();
    const hold = Math.max(600, Math.min(4000, m.holdMs != null ? m.holdMs : 1600));
    
    // Map dialogue intentions to 3D shapes
    const shapeMap = {
      'cube': 'cube',
      'box': 'cube', 
      'square': 'cube',
      'sphere': 'sphere',
      'ball': 'sphere',
      'circle': 'sphere',
      'spiral': 'helix',
      'helix': 'helix',
      'twist': 'helix',
      'ring': 'torus',
      'donut': 'torus',
      'torus': 'torus',
      'wave': 'wave',
      'ocean': 'wave',
      'flow': 'wave'
    };
    
    const targetShape = shapeMap[shape] || 'sphere';
    morphTo(targetShape, hold);
  };
  
  initializeParticles();
  step();
  }

  // Initialize when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initScene);
  } else {
    initScene();
  
  initializeParticles();
  step();
  }

  // Initialize when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initScene);
  } else {
    initScene();
  }
})();
