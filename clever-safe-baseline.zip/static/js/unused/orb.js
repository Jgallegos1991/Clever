// Deprecated file. Kept to avoid 404s if referenced somewhere. The new scene lives in scene.js.
